insert into users(name) values('mandy');
insert into users(name) values('nina');
insert into users(name) values('olga');