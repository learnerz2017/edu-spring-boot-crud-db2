package com.rpo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mdl.User;

@Repository
public interface UserRepository extends CrudRepository<User,Long> {

}
