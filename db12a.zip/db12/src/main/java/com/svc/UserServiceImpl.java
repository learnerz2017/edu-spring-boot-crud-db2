package com.svc;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mdl.User;
import com.rpo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;
	
	public List<User> findAll(){
		return (List<User>)userRepository.findAll();
	}
	
	public Optional<User> findById(Long id){
		return (Optional<User>) userRepository.findById(id);
	}
	
	public void deleteById(Long id) {
		userRepository.deleteById(id);
	}
	
	public Long save(User user) {
		return userRepository.save(user).getId();
	}
	
}
