package com.svc;

import java.util.List;
import java.util.Optional;

import com.mdl.User;

public interface UserService {
	public List<User> findAll();
	public Optional<User> findById(Long id);
	public void deleteById(Long id);
	public Long save(User user);
}
